import requests, urllib , time
from sys import argv
import sys
scode , site = argv
class get_resq:

    def __init__(self):
        self.status_code = 0
        self.encoding = None
        self.rsq = requests.request('GET', site)

    def shw_output(self):
        print("[!]The site URL you requested: \n", site)
        print("[!]Printing headers\n\t", self.rsq.headers, sep=' | ' , end=" | ")
        print( """
        [+] Below is website content\n
        
        Please check the written information for further information upon the target
        
        """, end='[+]')
        print(self.rsq.content)
    def Gather_Status(self):

        if self.rsq.status_code == 200:
            print("[+]Server is up and running 200 OK")
        elif self.rsq.encoding == 'utf-8':
            print("[+]The following server uses UTF-8 format")
        elif self.rsq.status_code == 443:
            print("[+]The server is using  HTTPS")
        elif self.rsq.status_code == 404:
            print("Webpage not found!")

    def Standardization(self):
        if self.rsq.status_code == 200:
            print("[+]Server is up and running 200 OK")
        elif self.rsq.encoding == 'utf-8':
            print("[+]The following server uses UTF-8 format")
        elif self.rsq.status_code == 443:
            print("[+]The server is using  HTTPS")
        elif self.rsq.encoding == 'ISO-8859-1':
            print("[+]The webpage is using an old standard")

    def wr_file(self):
        Get_reqq = input("Do you wish to format this into a JSON format?[+]\n")
        if Get_reqq == 'y' or 'Y':
            print("""Formatting into a JSON file... please wait""")
            jsf = open('site.txt', 'w')
            jsf.write("JSON FORMAT\n" + site)
        elif Get_reqq == 'n' or 'q':
            sys.exit(1)


    def _Gather_Cookies(self):
        Get_userinf = input("[*] Would you like to see cookies?")
        if Get_userinf == 'y' or 'Y':
            print("[+] Please wait a few seconds...")
            time.sleep(10)
            print(self.rsq.cookies)

        else:
            print("Exiting program within 10 seconds...")
            t = 11
            while t < 10:
                print(t)
                if t == 0:
                    sys.exit(1)
                    break


Clss_Instance = get_resq()

Clss_Instance.shw_output()