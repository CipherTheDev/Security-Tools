import os, re
import website_scanner
"""
Below are methods that are used to filter traffic based on the user's preferences.


"""
class FilterRequest:
    def __init__(self, header, http, ssl):
        self.header = header
        self.http = http
        self.ssl = ssl

    def http_filter(self):
        self.http = ""

    def ssl_filter(self):
        self.ssl = 0
        #determines ssl version
    def header_filter(self):
        self.header = None
